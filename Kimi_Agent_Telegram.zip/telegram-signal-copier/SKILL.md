---
name: telegram-signal-copier
description: Build and maintain a Telegram Signal Copier system that automatically copies trading signals from Telegram channels to MetaTrader 5 (MT5) and TradingView, with a comprehensive Trading Journal featuring daily/weekly automated reports. Use when working with forex/crypto trading automation, Telegram signal parsing, MT5 order execution, TradingView webhook integration, or trading journal/report generation.
---

# Telegram Signal Copier Skill

## Overview

Multi-platform trading signal automation system. Captures signals from Telegram channels, parses them into structured trade data, executes on MT5/TradingView, and maintains a full trading journal with automated reporting.

## Architecture Summary

```
Telegram Channels → Signal Parser → Risk Manager → Execution Queue → MT5/TradingView
                                                        ↓
                                              PostgreSQL Journal
                                                        ↓
                                              Daily/Weekly Reports
```

## Key Components

### 1. Signal Parser (`src/parser/`)

**Input**: Raw Telegram message text
**Output**: Structured signal JSON

**Pipeline**:
1. `preprocessor.py` — Strip markdown, normalize unicode, expand abbreviations
2. `patterns.py` — Keyword dictionary matching (configurable per provider)
3. `extractor.py` — Regex price/symbol extraction
4. `validator.py` — Required fields, sanity checks, deduplication

**Keyword Dictionary Format** (`config/keywords/{provider}.json`):
```json
{
  "EntryPointKeywords": "at,price,entry,@,now,zone",
  "TakeProfitKeywords": "take profit,tp,target",
  "StopLossKeywords": "stop loss,sl,sl@",
  "BuyKeywords": "buy,long",
  "SellKeywords": "sell,short",
  "BuyLimitKeywords": "buy limit,buy-limit",
  "ExceptionKeywords": "report,result,summary"
}
```

**Signal Output Schema**:
```json
{
  "signal_id": "uuid",
  "mode": "ENTRY|EXIT|MODIFY|IGNORE",
  "type": "BUY|SELL|BUY_LIMIT|SELL_LIMIT|BUY_STOP|SELL_STOP",
  "symbol": "EURUSD",
  "entry_price": "1.08500",
  "stop_loss": "1.08200",
  "take_profits": ["1.09000", "1.09500"],
  "lot_size": "0.01",
  "risk_percent": 2.0
}
```

### 2. MT5 Executor (`src/executors/mt5/`)

**Primary**: ZeroMQ direct connection to MT5 terminal
**Fallback**: File-based via `MQL5/Files/` directory

**ZeroMQ Protocol**:
```python
# REQUEST format (JSON)
{
  "action": "ORDER",
  "type": "MARKET_BUY",
  "symbol": "EURUSD",
  "volume": 0.01,
  "sl": 1.08200,
  "tp": 1.09000,
  "comment": "signal_copier"
}

# RESPONSE format
{
  "status": "OK|ERROR",
  "ticket": 123456789,
  "price": 1.08510,
  "error": ""
}
```

**MQL5 EA** (in `mql5/SignalExecutorEA/`):
- Monitors `MQL5/Files/Signals/` for JSON files
- Places orders based on signal content
- Deletes processed signal files
- Logs all actions to Experts tab

### 3. TradingView Executor (`src/executors/tradingview/`)

**Webhook Endpoint**: `POST /webhook/tradingview`
**Security**: HMAC-SHA256 signature verification

**Pine Script Template** (`pinescript/SignalConnector.pine`):
```pinescript
//@version=5
indicator("Signal Copier Connector", overlay=true)

// Signal conditions
longCondition = ta.crossover(ta.sma(close, 14), ta.sma(close, 28))
shortCondition = ta.crossunder(ta.sma(close, 14), ta.sma(close, 28))

// Webhook payload
if longCondition
    alert('{"action":"BUY","symbol":"' + syminfo.ticker + '","price":' + str.tostring(close) + '}', alert.freq_once_per_bar_close)

if shortCondition
    alert('{"action":"SELL","symbol":"' + syminfo.ticker + '","price":' + str.tostring(close) + '}', alert.freq_once_per_bar_close)
```

### 4. Risk Manager (`src/risk/`)

**Position Sizing Formula**:
```
lot_size = floor((balance * risk_percent) / (stop_loss_pips * pip_value * 10)) / 100
```

**Protection Rules**:
- Daily loss limit (default 5%)
- Max drawdown circuit breaker (default 10%)
- Max consecutive losses (default 5)
- Per-symbol exposure limit
- Total exposure limit

### 5. Trading Journal (`src/journal/`)

**Database**: PostgreSQL with tables: `signals`, `trades`, `trade_events`, `daily_summaries`, `weekly_summaries`, `provider_performance`

**Trade Event Types**:
- `entry` — Trade opened
- `tp1_hit`, `tp2_hit`, `tp3_hit` — Take profit reached
- `sl_hit` — Stop loss reached
- `partial_close` — Position partially closed
- `breakeven` — SL moved to entry
- `modified` — TP/SL updated
- `closed` — Trade fully closed

**Key Queries**:
```sql
-- Daily P&L
SELECT DATE(closed_at) as date, SUM(realized_pnl) as pnl, COUNT(*) as trades
FROM trades WHERE closed_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE(closed_at) ORDER BY date;

-- Provider performance
SELECT signal_provider,
  COUNT(*) as total_signals,
  SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
  AVG(realized_pnl) as avg_pnl
FROM trades JOIN signals ON trades.signal_id = signals.id
GROUP BY signal_provider;
```

### 6. Report Engine (`src/reports/`)

**Daily Report Sections**:
1. Executive Summary (trades, win rate, P&L)
2. Trade List with details
3. Equity curve chart
4. Symbol distribution chart
5. Provider performance table
6. Risk metrics (drawdown, R-multiple)

**Weekly Report Sections**:
1. Week overview
2. Day-by-day breakdown table
3. Cumulative performance chart
4. Provider rankings
5. Best/worst trade analysis

**Chart Functions** (matplotlib):
```python
def plot_equity_curve(trades: list[Trade]) -> plt.Figure:
    """Generate equity curve from trade history."""

def plot_win_loss_distribution(trades: list[Trade]) -> plt.Figure:
    """Daily win/loss bar chart."""

def plot_symbol_breakdown(trades: list[Trade]) -> plt.Figure:
    """Pie chart of trades by symbol."""

def plot_r_distribution(trades: list[Trade]) -> plt.Figure:
    """Histogram of R-multiples."""
```

**PDF Generator** (reportlab):
```python
def generate_daily_report(date: date, account_id: str) -> Path:
    """Generate daily PDF report with charts and tables."""

def generate_weekly_report(year: int, week: int, account_id: str) -> Path:
    """Generate weekly PDF report with comprehensive analysis."""
```

## Implementation Order

1. **Phase 1**: Parser + Telegram listener (Week 1-2)
2. **Phase 2**: MT5 ZeroMQ + MQL5 EA (Week 3-4)
3. **Phase 3**: TradingView webhook (Week 5)
4. **Phase 4**: PostgreSQL journal + analytics (Week 6)
5. **Phase 5**: Daily/weekly reports (Week 7)
6. **Phase 6**: Telegram bot commands (Week 8)
7. **Phase 7**: Testing + production (Week 9-10)

## Key Configuration

```yaml
# Essential config.yaml sections
telegram:
  api_id: ""
  api_hash: ""
  bot_token: ""
  monitored_channels: []

mt5:
  risk_management:
    default_risk_percent: 2.0
    max_daily_loss_percent: 5.0
    max_drawdown_percent: 10.0

journal:
  reporting:
    daily_report_time: "00:05"
    weekly_report_time: "00:10"
```

## Common Tasks

### Add New Signal Provider
1. Create `config/keywords/{provider}.json` with keyword dictionaries
2. Add channel to `monitored_channels` in config
3. Test with sample signals from that provider
4. Adjust keyword patterns if parsing fails

### Customize Report Schedule
- Modify `journal.reporting.daily_report_time` and `weekly_report_time` in config
- Uses APScheduler with cron expressions

### Handle New Symbol
- Add to symbol whitelist in config
- Set pip value multiplier for position sizing
- Verify MT5/TradingView supports the symbol

### Debug Signal Parsing
1. Check `signals` table for `status='failed'` or `error_message`
2. Review raw_message vs parsed_signal JSON
3. Adjust keyword dictionary patterns
4. Add custom preprocessor rule if needed
