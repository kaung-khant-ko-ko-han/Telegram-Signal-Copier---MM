# Telegram Signal Copier — System Architecture

## 1. Overview

A multi-platform signal copying system that captures trading signals from Telegram channels, parses them into structured data, and executes them automatically on MetaTrader 5 (MT5) and TradingView. Includes a comprehensive Trading Journal with daily/weekly automated reporting.

### Reference Projects Analyzed
- **oluklef17/telegram-mt4-mt5-signal-copier**: Desktop app (PyQt5 + Telethon) → MT4/MT5 via file-based signal passing + MQL EAs
- **oogunjob/FX-Signal-Copier-Telegram-Bot**: Telegram bot → MetaAPI Cloud → MT4, with risk calculation and Heroku deployment

---

## 2. High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           TELEGRAM LAYER                                     │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐       │
│  │ Signal Channels  │    │ Command Bot      │    │ Admin Channel    │       │
│  │ (Public/Private) │    │ (User Commands)  │    │ (Reports/Alerts) │       │
│  └────────┬─────────┘    └────────┬─────────┘    └────────▲─────────┘       │
└───────────┼───────────────────────┼──────────────────────┼─────────────────┘
            │                       │                      │
            ▼                       ▼                      │
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CORE ENGINE (Python/FastAPI)                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ Telegram     │  │ Signal       │  │ Risk         │  │ Journal      │    │
│  │ Listener     │──▶│ Parser       │──▶│ Manager      │──▶│ Engine       │    │
│  │ (Telethon)   │  │ (NLP/Regex)  │  │              │  │              │    │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘    │
│         │                   │                  │                  │          │
│         ▼                   ▼                  ▼                  ▼          │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    STATE & MESSAGE BUS (Redis)                       │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌───────────┐  │    │
│  │  │ Signal Queue│  │ Trade State │  │ User Session│  │ Pub/Sub   │  │    │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └───────────┘  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
            │                       │                      │
            ▼                       ▼                      ▼
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│   MT5 EXECUTOR   │    │ TRADINGVIEW EXEC │    │   JOURNAL DB     │
│   (MetaTrader5)  │    │  (Pine Connector)│    │  (PostgreSQL)    │
│                  │    │                  │    │                  │
│ ┌──────────────┐ │    │ ┌──────────────┐ │    │ ┌──────────────┐ │
│ │ MT5 Terminal │ │    │ │ Webhook      │ │    │ │ Trades Table │ │
│ │ via ZeroMQ   │ │    │ │ Server       │ │    │ │ Signals Table│ │
│ │              │ │    │ │              │ │    │ │ Reports Table│ │
│ └──────────────┘ │    │ └──────────────┘ │    │ │ Journal Table│ │
│                  │    │                  │    │ └──────────────┘ │
│ ┌──────────────┐ │    │ ┌──────────────┐ │    └──────────────────┘
│ │ MQL5 EA      │ │    │ │ Pine Script  │ │              │
│ │ (Fallback)   │ │    │ │ (Alerts)     │ │              ▼
│ └──────────────┘ │    │ └──────────────┘ │    ┌──────────────────┐
└──────────────────┘    └──────────────────┘    │  REPORT ENGINE   │
                                                │  (Daily/Weekly)  │
                                                │                  │
                                                │ ┌──────────────┐ │
                                                │ │ PDF Generator│ │
                                                │ │ Chart Builder│ │
                                                │ │ Telegram Bot │ │
                                                │ └──────────────┘ │
                                                └──────────────────┘
```

---

## 3. Component Breakdown

### 3.1 Telegram Layer

#### 3.1.1 Signal Listener Module
- **Technology**: Telethon (async Telegram MTProto client)
- **Purpose**: Monitor configured Telegram channels/groups for trading signals
- **Features**:
  - Real-time message listening via Telegram API
  - Support for private channels, public channels, and groups
  - Edited message detection (signal updates)
  - Reply thread tracking (context for signal modifications)
  - Media/attachment handling (some signals come as images)
  - Message deduplication via message_id hashing

#### 3.1.2 Command Bot Module
- **Technology**: python-telegram-bot (PTB v20+)
- **Purpose**: User-facing bot for configuration and control
- **Commands**:
  - `/start` — Initialize user session
  - `/connect` — Link MT5/TradingView account
  - `/channels` — Manage monitored channels
  - `/risk` — Configure risk parameters
  - `/journal` — View trading journal
  - `/report` — Generate manual report
  - `/status` — System health check
  - `/pause` — Pause copying
  - `/resume` — Resume copying

#### 3.1.3 Admin/Notification Channel
- Dedicated channel for system alerts, error reports, daily summaries

---

### 3.2 Core Engine

#### 3.2.1 Signal Parser Module
**Multi-Strategy Parsing Pipeline:**

```
Raw Message → Preprocessing → Keyword Pattern Match → NLP Extraction → Validation → Structured Signal
```

**Preprocessing**:
- Strip markdown formatting (**bold**, __underline__, etc.)
- Normalize unicode characters
- Remove emojis (or extract them as sentiment indicators)
- Expand abbreviations (TP→Take Profit, SL→Stop Loss, BE→Breakeven)
- Handle conjoined text (e.g., "TP1.2345" → "TP 1.2345")

**Keyword Pattern Matching** (from oluklef17 approach):
- JSON-configurable keyword dictionaries per signal provider
- Pattern categories: EntryPointKeywords, TakeProfitKeywords, StopLossKeywords, BuyKeywords, SellKeywords, etc.
- Dynamic placeholder patterns with `[X]` for indexed items (TP1, TP2, SL1, etc.)
- Symbol detection with configurable symbol lists per provider

**NLP Extraction** (enhancement):
- Regex-based price extraction with multi-format support
- Pips vs. price level detection
- Order type classification (BUY/SELL/BUY LIMIT/SELL LIMIT/BUY STOP/SELL STOP)
- Number context awareness (distinguish entry price from TP/SL)

**Validation**:
- Required field checking (symbol, direction, entry, SL)
- Price level sanity checks
- Symbol existence verification
- Duplicate detection (same signal within time window)

**Output Schema**:
```json
{
  "signal_id": "uuid",
  "mode": "ENTRY|EXIT|MODIFY|IGNORE",
  "type": "BUY|SELL|BUY_LIMIT|SELL_LIMIT|BUY_STOP|SELL_STOP|...",
  "symbol": "EURUSD",
  "entry_price": "1.08500",
  "stop_loss": "1.08200",
  "take_profits": ["1.09000", "1.09500"],
  "lot_size": "0.01",
  "risk_percent": 2.0,
  "timeframe": "H1",
  "source_channel": "@channel_name",
  "message_id": 12345,
  "timestamp": "2026-06-07T12:00:00Z",
  "raw_message": "...",
  "parsed_at": "2026-06-07T12:00:02Z"
}
```

#### 3.2.2 Risk Manager Module
- **Position Sizing**: Calculate lot size based on account balance, risk %, and stop loss distance
- **Account Balance Protection**: Daily loss limits, consecutive loss protection
- **Risk Profiles**: Conservative (1%), Moderate (2%), Aggressive (3%)
- **Dynamic Leverage Adjustment**: Based on symbol and broker constraints
- **Maximum Exposure**: Per-symbol and total exposure limits
- **Drawdown Circuit Breaker**: Auto-pause on account drawdown threshold

#### 3.2.3 Journal Engine Module
- **Real-time Trade Logging**: Every signal → trade execution logged with full metadata
- **P&L Tracking**: Realized and unrealized P&L per trade, per day, per week, per month
- **Signal Provider Performance**: Win rate, average R:R, profit factor per channel
- **Trade Lifecycle Tracking**: Entry → TP/SL hit → Partial close → Breakeven → Exit

---

### 3.3 State & Message Bus (Redis)

| Keyspace | Purpose | TTL |
|----------|---------|-----|
| `signal:{id}` | Parsed signal data | 24h |
| `trade:{id}` | Trade execution state | 7d |
| `user:{id}` | User session & config | Session |
| `channel:{id}` | Channel configuration | Persistent |
| `queue:mt5` | MT5 execution queue | - |
| `queue:tv` | TradingView execution queue | - |
| `pubsub:signals` | Signal broadcast channel | - |
| `locks:{resource}` | Distributed locks | 30s |

---

### 3.4 Execution Layer

#### 3.4.1 MT5 Executor
**Primary Method: ZeroMQ Integration**
- **Technology**: `MetaTrader5` Python package + ZeroMQ EA
- **Architecture**: Python client ↔ MT5 terminal via ZeroMQ socket
- **Features**:
  - Direct order placement (market, limit, stop)
  - Order modification (SL/TP updates)
  - Partial close support
  - Position monitoring
  - Real-time price feeds

**Fallback Method: MQL5 EA** (from oluklef17 approach)
- File-based signal passing via `MQL5/Files/` directory
- JSON signal files watched by EA
- Useful when ZeroMQ is unavailable

**Order Types Supported**:
- MARKET_BUY / MARKET_SELL
- LIMIT_BUY / LIMIT_SELL
- STOP_BUY / STOP_SELL
- With multiple TP splits (e.g., 50% at TP1, 50% at TP2)

#### 3.4.2 TradingView Executor
- **Webhook Server**: FastAPI endpoint receiving TradingView alerts
- **Pine Script Connector**: Custom Pine Script sending alert webhook JSON
- **TradingView Broker API**: Direct integration where available

**Pine Script Alert Format**:
```pinescript
// Example Pine Connector Script
if (signal_condition)
    alert(json_encode({
        "symbol": syminfo.ticker,
        "action": "buy",
        "price": close,
        "sl": sl_level,
        "tp": tp_level
    }), alert.freq_once_per_bar_close)
```

**Webhook Payload**:
```json
{
  "platform": "tradingview",
  "signal_id": "uuid",
  "symbol": "EURUSD",
  "action": "BUY",
  "entry": 1.08500,
  "sl": 1.08200,
  "tp": [1.09000],
  "timestamp": "2026-06-07T12:00:00Z"
}
```

---

### 3.5 Journal Database (PostgreSQL)

#### 3.5.1 Schema Design

```sql
-- Signals Table
CREATE TABLE signals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    raw_message TEXT NOT NULL,
    parsed_signal JSONB NOT NULL,
    source_channel VARCHAR(255),
    source_channel_id BIGINT,
    message_id BIGINT,
    signal_provider VARCHAR(255),
    status VARCHAR(50) DEFAULT 'pending', -- pending, executed, failed, ignored
    created_at TIMESTAMPTZ DEFAULT NOW(),
    executed_at TIMESTAMPTZ,
    error_message TEXT
);

-- Trades Table
CREATE TABLE trades (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id UUID REFERENCES signals(id),
    platform VARCHAR(50) NOT NULL, -- mt5, tradingview
    account_id VARCHAR(255) NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    direction VARCHAR(10) NOT NULL, -- BUY, SELL
    order_type VARCHAR(20) NOT NULL, -- MARKET, LIMIT, STOP
    entry_price DECIMAL(15,5),
    stop_loss DECIMAL(15,5),
    take_profits DECIMAL(15,5)[],
    lot_size DECIMAL(10,2),
    risk_percent DECIMAL(5,2),
    status VARCHAR(50) DEFAULT 'open', -- open, closed, partial, cancelled
    opened_at TIMESTAMPTZ,
    closed_at TIMESTAMPTZ,
    close_price DECIMAL(15,5),
    realized_pnl DECIMAL(15,2),
    pips DECIMAL(10,2),
    r_multiple DECIMAL(5,2),
    partial_closes JSONB DEFAULT '[]',
    ticket_number VARCHAR(100),
    magic_number BIGINT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Trade Events Table (Lifecycle Tracking)
CREATE TABLE trade_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trade_id UUID REFERENCES trades(id),
    event_type VARCHAR(50) NOT NULL, -- tp1_hit, tp2_hit, sl_hit, breakeven, partial_close, modified
    description TEXT,
    pnl_at_event DECIMAL(15,2),
    data JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Daily Performance Summary
CREATE TABLE daily_summaries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    account_id VARCHAR(255) NOT NULL,
    total_trades INT DEFAULT 0,
    winning_trades INT DEFAULT 0,
    losing_trades INT DEFAULT 0,
    breakeven_trades INT DEFAULT 0,
    total_pnl DECIMAL(15,2) DEFAULT 0,
    gross_profit DECIMAL(15,2) DEFAULT 0,
    gross_loss DECIMAL(15,2) DEFAULT 0,
    profit_factor DECIMAL(8,2),
    average_win DECIMAL(10,2),
    average_loss DECIMAL(10,2),
    average_r DECIMAL(5,2),
    max_drawdown DECIMAL(10,2),
    max_consecutive_wins INT DEFAULT 0,
    max_consecutive_losses INT DEFAULT 0,
    symbols_traded VARCHAR(20)[],
    providers JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(date, account_id)
);

-- Weekly Performance Summary
CREATE TABLE weekly_summaries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    year INT NOT NULL,
    week INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    account_id VARCHAR(255) NOT NULL,
    total_trades INT DEFAULT 0,
    winning_trades INT DEFAULT 0,
    losing_trades INT DEFAULT 0,
    total_pnl DECIMAL(15,2) DEFAULT 0,
    gross_profit DECIMAL(15,2) DEFAULT 0,
    gross_loss DECIMAL(15,2) DEFAULT 0,
    profit_factor DECIMAL(8,2),
    win_rate DECIMAL(5,2),
    average_r DECIMAL(5,2),
    max_drawdown DECIMAL(10,2),
    best_day_pnl DECIMAL(15,2),
    worst_day_pnl DECIMAL(15,2),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(year, week, account_id)
);

-- Signal Provider Performance
CREATE TABLE provider_performance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_name VARCHAR(255) NOT NULL,
    channel_id BIGINT,
    total_signals INT DEFAULT 0,
    executed_signals INT DEFAULT 0,
    winning_trades INT DEFAULT 0,
    losing_trades INT DEFAULT 0,
    total_pnl DECIMAL(15,2) DEFAULT 0,
    win_rate DECIMAL(5,2),
    average_rr DECIMAL(5,2),
    profit_factor DECIMAL(8,2),
    avg_pips_profit DECIMAL(8,2),
    avg_pips_loss DECIMAL(8,2),
    last_signal_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(provider_name, channel_id)
);
```

---

### 3.6 Report Engine

#### 3.6.1 Daily Report
- **Schedule**: Every day at 00:05 UTC
- **Content**:
  - Total trades executed
  - Win/Loss count and rate
  - Net P&L (currency and pips)
  - Average R-multiple
  - Profit factor
  - Best/Worst trade
  - Symbol breakdown
  - Signal provider performance
  - Equity curve chart
  - Trade distribution heatmap
- **Delivery**: Telegram message + PDF attachment + Web dashboard

#### 3.6.2 Weekly Report
- **Schedule**: Every Monday at 00:10 UTC
- **Content**:
  - Weekly summary with day-by-day breakdown
  - Cumulative statistics
  - Drawdown analysis
  - Provider ranking
  - Strategy insights
  - Comparison with previous week
- **Delivery**: Telegram message + Comprehensive PDF report + Interactive charts

#### 3.6.3 Report Generation Pipeline
```
Database Query → Data Aggregation → Chart Generation (matplotlib/plotly) → 
PDF Assembly (reportlab) → Telegram Delivery → Archive
```

---

## 4. Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Language** | Python 3.11+ | Core runtime |
| **API Framework** | FastAPI | Webhook server, REST API |
| **Telegram Client** | Telethon | Signal channel monitoring |
| **Telegram Bot** | python-telegram-bot v20+ | Command interface |
| **Database** | PostgreSQL 15+ | Journal storage |
| **Cache/Queue** | Redis 7+ | State management, message bus |
| **MT5 Integration** | MetaTrader5 + ZeroMQ | Order execution |
| **TradingView** | FastAPI webhooks + Pine Script | Alert reception |
| **Scheduling** | APScheduler | Report generation |
| **Charts** | matplotlib + plotly | Report visualizations |
| **PDF** | reportlab | Report generation |
| **Task Queue** | Celery + Redis | Background processing |
| **Container** | Docker + Docker Compose | Deployment |
| **Monitoring** | Prometheus + Grafana | Metrics and alerting |

---

## 5. Data Flow

### 5.1 Signal Detection → Execution Flow
```
1. Telegram Message Received (Telethon)
   ↓
2. Preprocessing (strip format, normalize)
   ↓
3. Pattern Matching (keyword dictionaries)
   ↓
4. Signal Validation (required fields, sanity checks)
   ↓
5. Risk Calculation (position sizing, limits)
   ↓
6. Save to Database (signals table)
   ↓
7. Push to Execution Queue (Redis)
   ↓
8. Executor Dequeue (Celery worker)
   ↓
9. Platform-Specific Execution (MT5/TradingView)
   ↓
10. Execution Confirmation → Update Database
   ↓
11. Telegram Notification (result to user)
   ↓
12. Journal Entry (trades table)
```

### 5.2 Report Generation Flow
```
1. Scheduled Trigger (APScheduler)
   ↓
2. Aggregate Trade Data (SQL queries)
   ↓
3. Calculate Statistics (Python)
   ↓
4. Generate Charts (matplotlib)
   ↓
5. Assemble PDF (reportlab)
   ↓
6. Send via Telegram Bot
   ↓
7. Store in Archive
```

---

## 6. Configuration Schema

```yaml
# config.yaml
system:
  name: "Telegram Signal Copier"
  environment: "production"
  log_level: "INFO"
  timezone: "UTC"

telegram:
  api_id: "YOUR_API_ID"
  api_hash: "YOUR_API_HASH"
  bot_token: "YOUR_BOT_TOKEN"
  admin_user_id: "YOUR_TELEGRAM_ID"
  notification_channel: "@your_channel"
  monitored_channels:
    - id: -1001234567890
      name: "Premium Signals"
      provider: "SignalProviderA"
      active: true
      keywords_config: "provider_a.json"
    - id: -1000987654321
      name: "Free Signals"
      provider: "SignalProviderB"
      active: false
      keywords_config: "provider_b.json"

mt5:
  enabled: true
  account:
    login: 12345678
    password: ""
    server: "Broker-Server"
  risk_management:
    default_risk_percent: 2.0
    max_daily_loss_percent: 5.0
    max_drawdown_percent: 10.0
    max_consecutive_losses: 5
    max_total_exposure: 10.0
    max_positions_per_symbol: 2
  execution:
    use_zeromq: true
    zeromq_port: 15555
    fallback_to_file: true
    slippage_pips: 3
    retry_attempts: 3

tradingview:
  enabled: true
  webhook:
    host: "0.0.0.0"
    port: 8080
    path: "/webhook/tradingview"
    secret: "your_webhook_secret"

journal:
  enabled: true
  reporting:
    daily_report_time: "00:05"
    weekly_report_day: "Monday"
    weekly_report_time: "00:10"
    report_format: ["telegram", "pdf"]
    retention_days: 365

database:
  host: "localhost"
  port: 5432
  name: "signal_copier"
  user: "copier"
  password: ""

redis:
  host: "localhost"
  port: 6379
  db: 0

advanced:
  signal_dedup_window_seconds: 60
  partial_tp_splits: [0.5, 0.5]
  auto_breakeven_after_tp1: false
  trailing_stop_enabled: false
  news_filter_enabled: false
```

---

## 7. Security Considerations

- **API Credentials**: Environment variables or Docker secrets (never hardcoded)
- **Webhook Security**: HMAC signature verification for TradingView webhooks
- **Telegram Auth**: User whitelist for bot commands
- **Database**: Connection encryption, least-privilege user
- **MT5**: Demo account testing before live trading
- **Rate Limiting**: Prevent abuse on webhook endpoints
- **Audit Logging**: All actions logged with timestamps

---

## 8. Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Docker Host                           │
│                                                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │
│  │   FastAPI   │  │   Celery    │  │  Telegram   │     │
│  │   Server    │  │   Worker    │  │   Bot       │     │
│  │   (API +    │  │             │  │   (PTB)     │     │
│  │   Webhooks) │  │             │  │             │     │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘     │
│         │                │                │             │
│  ┌──────┴────────────────┴────────────────┴──────┐     │
│  │              Docker Network                    │     │
│  │         ┌──────────┐    ┌──────────┐           │     │
│  │         │PostgreSQL│    │  Redis   │           │     │
│  │         │   5432   │    │   6379   │           │     │
│  │         └──────────┘    └──────────┘           │     │
│  └────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────┘
```

---

## 9. Error Handling & Recovery

| Scenario | Strategy |
|----------|----------|
| MT5 Disconnection | Retry with exponential backoff; queue signals |
| Parse Failure | Log raw message; notify admin; skip |
| Invalid Signal | Log with error reason; skip execution |
| Execution Reject | Retry once; log rejection reason |
| Database Failure | Queue to Redis; retry; alert admin |
| Telegram API Rate Limit | Backoff; queue messages |
| Duplicate Signal | Check hash within dedup window; skip |
| News/Event (High Spread) | Optional: pause execution during news |
