# Trading Journal & Reporting System Design

## 1. Philosophy

Every trade tells a story. The journal captures not just what happened, but why it happened, how it performed, and what patterns emerge over time. The goal is **data-driven trading improvement** through comprehensive tracking and insightful reporting.

## 2. Data Model Deep Dive

### 2.1 Signal Lifecycle

```
RECEIVED → PARSED → VALIDATED → QUEUED → EXECUTED → TRACKED → CLOSED → ARCHIVED
   │          │          │          │          │          │         │
   ▼          ▼          ▼          ▼          ▼          ▼         ▼
  raw      parsed    valid/    in queue   ticket    open    realized
 message    signal   invalid              number   position   P&L
```

**Status Transitions**:
- `pending` → `validated` (passed validation)
- `validated` → `queued` (pushed to execution queue)
- `queued` → `executed` (order placed successfully)
- `queued` → `failed` (execution error)
- `pending` → `ignored` (exception keywords matched)
- `pending` → `invalid` (validation failed)

### 2.2 Trade Lifecycle Events

```
ENTRY ──▶ TP1_HIT ──▶ TP2_HIT ──▶ FULL_CLOSE (profit)
   │         │
   │         └──▶ PARTIAL_CLOSE
   │
   └──▶ SL_HIT ──▶ FULL_CLOSE (loss)
   │
   └──▶ BREAKEVEN ──▶ SL_HIT@ENTRY (breakeven)
   │
   └──▶ MODIFIED (SL/TP updated)
```

### 2.3 Entity Relationships

```
┌─────────────┐     1:N     ┌─────────────┐     1:N     ┌─────────────┐
│   signals   │─────────────▶│   trades    │─────────────▶│trade_events │
└─────────────┘              └─────────────┘              └─────────────┘
       │                            │
       │ 1:1                        │ N:1
       ▼                            ▼
┌─────────────┐              ┌─────────────┐
│raw_messages │              │provider_perf│
└─────────────┘              └─────────────┘
```

## 3. Journal Entry Schema

### 3.1 Minimal Journal Entry (Auto-Captured)

```json
{
  "entry_id": "uuid",
  "timestamp": "2026-06-07T14:30:00Z",
  "type": "ENTRY|EXIT|MODIFY|NOTE",
  "trade_id": "uuid",
  
  "signal_source": {
    "channel": "@PremiumSignals",
    "provider": "ForexMaster",
    "message_id": 12345,
    "message_link": "https://t.me/c/..."
  },
  
  "trade_details": {
    "symbol": "EURUSD",
    "direction": "BUY",
    "entry_price": 1.08500,
    "stop_loss": 1.08200,
    "take_profits": [1.09000, 1.09500],
    "lot_size": 0.10,
    "risk_percent": 2.0,
    "risk_reward": "1:2.5"
  },
  
  "execution": {
    "platform": "mt5",
    "ticket_number": "123456789",
    "magic_number": 1001,
    "open_time": "2026-06-07T14:30:15Z",
    "slippage_pips": 0.5,
    "commission": -3.50,
    "swap": 0.00
  },
  
  "outcome": {
    "status": "CLOSED",
    "close_price": 1.09000,
    "close_time": "2026-06-07T18:45:00Z",
    "realized_pnl": 45.00,
    "pips": 50,
    "r_multiple": 2.5,
    "exit_reason": "TP1_HIT"
  }
}
```

### 3.2 Extended Journal Entry (With Manual Notes)

```json
{
  "...": "... (minimal fields)",
  
  "manual_notes": {
    "setup_quality": 8,
    "emotional_state": "calm",
    "market_context": "trending bullish, London session",
    "lessons": "Good entry at support, could have added on pullback",
    "tags": ["trend-following", "support-bounce", "london-session"]
  },
  
  "screenshots": [
    "https://storage/journal/uuid_entry.png",
    "https://storage/journal/uuid_exit.png"
  ]
}
```

## 4. Analytics Calculations

### 4.1 Core Metrics

| Metric | Formula | Description |
|--------|---------|-------------|
| **Win Rate** | `wins / total_trades * 100` | Percentage of winning trades |
| **Profit Factor** | `gross_profit / abs(gross_loss)` | Ratio of profits to losses |
| **Average Win** | `sum(wins) / count(wins)` | Mean profit per winning trade |
| **Average Loss** | `sum(losses) / count(losses)` | Mean loss per losing trade |
| **Average R** | `sum(r_multiples) / count(trades)` | Mean R-multiple per trade |
| **Expectancy** | `(win_rate * avg_win) - (loss_rate * avg_loss)` | Expected value per trade |
| **Max Drawdown** | Max peak-to-trough decline | Largest account decline |
| **Sharpe Ratio** | `(return - risk_free) / std_dev` | Risk-adjusted return |
| **Recovery Factor** | `net_profit / max_drawdown` | Profit vs. max drawdown |

### 4.2 R-Multiple Calculation

```python
def calculate_r_multiple(trade: Trade) -> float:
    """
    R = (close_price - entry_price) / (entry_price - stop_loss)
    
    For BUY:  positive R = profit, negative R = loss
    For SELL: negative R = profit, positive R = loss (inverted)
    """
    entry_sl_distance = abs(trade.entry_price - trade.stop_loss)
    if entry_sl_distance == 0:
        return 0
    
    if trade.direction == "BUY":
        pnl_distance = trade.close_price - trade.entry_price
    else:
        pnl_distance = trade.entry_price - trade.close_price
    
    return round(pnl_distance / entry_sl_distance, 2)
```

### 4.3 Pips Calculation

```python
def calculate_pips(trade: Trade) -> float:
    """
    Symbol-specific pip calculation.
    JPY pairs: 1 pip = 0.01
    XAUUSD: 1 pip = 0.1
    XAGUSD: 1 pip = 0.001
    Others: 1 pip = 0.0001
    """
    multipliers = {
        "JPY": 0.01,
        "XAUUSD": 0.1,
        "XAGUSD": 0.001,
        "DEFAULT": 0.0001
    }
    
    multiplier = multipliers.get(trade.symbol[-3:], multipliers["DEFAULT"])
    if "XAU" in trade.symbol or "GOLD" in trade.symbol:
        multiplier = 0.1
    elif "XAG" in trade.symbol or "SILVER" in trade.symbol:
        multiplier = 0.001
    
    price_diff = trade.close_price - trade.entry_price
    if trade.direction == "SELL":
        price_diff = -price_diff
    
    return round(price_diff / multiplier, 1)
```

## 5. Report Templates

### 5.1 Daily Report (Telegram Format)

```
📊 DAILY TRADING REPORT — June 7, 2026
═══════════════════════════════════════

📈 SUMMARY
   Trades:     8
   Wins:       5 (62.5%)
   Losses:     3 (37.5%)
   Net P&L:    +$247.50 💰
   Net Pips:   +35.2

💵 FINANCIAL
   Gross Profit:  +$420.00
   Gross Loss:    -$172.50
   Profit Factor: 2.43
   Avg R:         +1.8R

📋 TRADE LIST
   #1 EURUSD BUY  +$85.00  +12.5p  +2.5R ✅
   #2 GBPUSD SELL -$45.00  -8.2p   -1.0R ❌
   #3 USDJPY BUY  +$120.00 +18.0p  +3.0R ✅
   #4 XAUUSD BUY  +$95.00  +9.5p   +2.0R ✅
   #5 EURUSD SELL -$67.50  -11.0p  -1.5R ❌
   #6 AUDUSD BUY  +$35.00  +6.0p   +1.2R ✅
   #7 GBPJPY BUY  +$85.00  +14.0p  +2.8R ✅
   #8 EURUSD BUY  -$60.00  -7.5p   -1.2R ❌

🏆 BEST: USDJPY BUY  +$120.00  +3.0R
   😞 WORST: GBPUSD SELL -$45.00  -1.0R

📊 BY SYMBOL
   EURUSD: 3 trades, +$42.50
   GBPUSD: 1 trade,  -$45.00
   USDJPY: 1 trade,  +$120.00
   XAUUSD: 1 trade,  +$95.00
   AUDUSD: 1 trade,  +$35.00

👤 BY PROVIDER
   PremiumSignals: 5 trades, 60% WR, +$198.00
   FreeSignals:    3 trades, 66% WR, +$49.50

⚠️ RISK STATUS
   Daily Loss:  2.1% / 5.0% limit
   Drawdown:    4.2% / 10.0% limit
   Consecutive: 1 loss (max: 5)

═══════════════════════════════════════
📄 Full PDF report attached
```

### 5.2 Weekly Report (PDF Sections)

**Cover Page**:
- Week range (June 1-7, 2026)
- Total P&L with visual indicator (green/red)
- Key metrics: trades, win rate, profit factor, avg R

**Page 1: Week Overview**:
- Summary table
- Week vs. previous week comparison
- Cumulative equity curve (MTD)

**Page 2: Day-by-Day Breakdown**:
| Day | Trades | Wins | Losses | P&L | Cumulative |
|-----|--------|------|--------|-----|------------|
| Mon | 5 | 3 | 2 | +$120 | +$120 |
| Tue | 8 | 5 | 3 | +$247 | +$367 |
| ... | ... | ... | ... | ... | ... |

**Page 3: Charts**:
- Equity curve (line chart)
- Daily P&L bars (green/red)
- Win/loss pie chart
- Symbol distribution pie chart
- R-multiple distribution histogram

**Page 4: Provider Analysis**:
- Provider ranking table
- Per-provider win rate and P&L
- Provider consistency score

**Page 5: Risk Metrics**:
- Drawdown chart
- Consecutive win/loss streaks
- Risk-reward analysis
- Exposure timeline

**Page 6: Insights**:
- Best performing symbol
- Best performing provider
- Optimal session times (if timestamp data available)
- Recommendations

## 6. Database Aggregation Queries

### 6.1 Daily Summary Generation

```sql
-- Upsert daily summary
INSERT INTO daily_summaries (
    date, account_id, total_trades, winning_trades, losing_trades,
    breakeven_trades, total_pnl, gross_profit, gross_loss,
    profit_factor, average_win, average_loss, average_r, max_drawdown
)
SELECT 
    DATE(closed_at) as date,
    account_id,
    COUNT(*) as total_trades,
    SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as winning_trades,
    SUM(CASE WHEN realized_pnl < 0 THEN 1 ELSE 0 END) as losing_trades,
    SUM(CASE WHEN realized_pnl = 0 THEN 1 ELSE 0 END) as breakeven_trades,
    SUM(realized_pnl) as total_pnl,
    SUM(CASE WHEN realized_pnl > 0 THEN realized_pnl ELSE 0 END) as gross_profit,
    SUM(CASE WHEN realized_pnl < 0 THEN realized_pnl ELSE 0 END) as gross_loss,
    NULL, -- calculated after insert
    AVG(CASE WHEN realized_pnl > 0 THEN realized_pnl END) as average_win,
    AVG(CASE WHEN realized_pnl < 0 THEN realized_pnl END) as average_loss,
    AVG(r_multiple) as average_r,
    NULL  -- calculated separately
FROM trades
WHERE DATE(closed_at) = :target_date AND account_id = :account_id
GROUP BY DATE(closed_at), account_id
ON CONFLICT (date, account_id) DO UPDATE SET ...;
```

### 6.2 Provider Performance Update

```sql
-- Update provider performance after each closed trade
INSERT INTO provider_performance (
    provider_name, channel_id, total_signals, executed_signals,
    winning_trades, losing_trades, total_pnl
)
SELECT 
    s.signal_provider,
    s.source_channel_id,
    COUNT(DISTINCT s.id),
    COUNT(DISTINCT t.id),
    SUM(CASE WHEN t.realized_pnl > 0 THEN 1 ELSE 0 END),
    SUM(CASE WHEN t.realized_pnl < 0 THEN 1 ELSE 0 END),
    SUM(t.realized_pnl)
FROM signals s
JOIN trades t ON t.signal_id = s.id
WHERE s.signal_provider = :provider
GROUP BY s.signal_provider, s.source_channel_id
ON CONFLICT (provider_name, channel_id) DO UPDATE SET ...;
```

## 7. Report Generation Pipeline

```python
async def generate_daily_report(date: date, account_id: str) -> Report:
    """Generate daily trading report."""
    
    # 1. Fetch data
    trades = await fetch_trades_for_date(date, account_id)
    summary = await get_or_compute_daily_summary(date, account_id)
    providers = await get_provider_stats_for_date(date, account_id)
    
    # 2. Generate charts
    equity_chart = plot_equity_curve(trades)
    distribution_chart = plot_win_loss_distribution(trades)
    symbol_chart = plot_symbol_breakdown(trades)
    r_chart = plot_r_distribution(trades)
    
    # 3. Build Telegram message
    telegram_text = format_daily_telegram(summary, trades, providers)
    
    # 4. Build PDF
    pdf_path = build_daily_pdf(summary, trades, providers, [
        equity_chart, distribution_chart, symbol_chart, r_chart
    ])
    
    # 5. Send
    await send_telegram_report(telegram_text, pdf_path)
    
    # 6. Archive
    await archive_report(date, account_id, pdf_path)
    
    return Report(text=telegram_text, pdf=pdf_path)
```

## 8. Scheduling

```python
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

scheduler = AsyncIOScheduler()

# Daily report at 00:05 UTC
scheduler.add_job(
    generate_daily_report,
    CronTrigger(hour=0, minute=5),
    id="daily_report"
)

# Weekly report Monday at 00:10 UTC
scheduler.add_job(
    generate_weekly_report,
    CronTrigger(day_of_week="mon", hour=0, minute=10),
    id="weekly_report"
)

# Daily summary computation at 00:02 UTC
scheduler.add_job(
    compute_daily_summary,
    CronTrigger(hour=0, minute=2),
    id="daily_summary"
)

scheduler.start()
```

## 9. Manual Journal Entry (Bot Command)

```
User: /journal add
Bot: 📓 New journal entry
     Symbol? (e.g., EURUSD)
User: EURUSD
Bot: Direction? (BUY/SELL)
User: BUY
Bot: Entry price?
User: 1.08500
Bot: Stop loss?
User: 1.08200
Bot: Take profit(s)? (comma separated)
User: 1.09000, 1.09500
Bot: Outcome? (WIN/LOSS/BREAKEVEN/MANUAL_CLOSE)
User: WIN
Bot: P&L in $? (optional, press skip)
User: +85
Bot: Notes? (optional)
User: Good setup at support, followed plan
Bot: ✅ Journal entry saved!
```

## 10. Data Retention Policy

| Data Type | Retention | Action |
|-----------|-----------|--------|
| Raw signals | 90 days | Archive to cold storage |
| Trade details | 3 years | Keep in hot storage |
| Daily summaries | 3 years | Keep in hot storage |
| Weekly summaries | 5 years | Keep in hot storage |
| PDF reports | 1 year | Compress and archive |
| Trade events | 3 years | Keep with trade records |
| Provider performance | Indefinite | Keep all historical |
