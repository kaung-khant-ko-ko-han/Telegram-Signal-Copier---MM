# Telegram Signal Copier — Implementation Plan

## Phase Overview

| Phase | Name | Duration | Deliverables |
|-------|------|----------|-------------|
| **Phase 1** | Foundation & Core Parser | Week 1-2 | Telegram listener, signal parser, config system |
| **Phase 2** | MT5 Integration | Week 3-4 | ZeroMQ connection, order execution, MQL5 EA fallback |
| **Phase 3** | TradingView Integration | Week 5 | Webhook server, Pine Script connector |
| **Phase 4** | Trading Journal & Database | Week 6 | PostgreSQL schema, trade logging, event tracking |
| **Phase 5** | Reporting Engine | Week 7 | Daily/weekly reports, PDF generation, charts |
| **Phase 6** | Bot Interface & Polish | Week 8 | Telegram bot commands, admin panel, Docker deployment |
| **Phase 7** | Testing & Production | Week 9-10 | Demo testing, bug fixes, performance optimization |

---

## Phase 1: Foundation & Core Parser (Week 1-2)

### 1.1 Project Structure Setup
```
telegram-signal-copier/
├── src/
│   ├── __init__.py
│   ├── config/               # Configuration management
│   │   ├── __init__.py
│   │   ├── settings.py       # Pydantic settings
│   │   └── logging.yaml      # Log configuration
│   ├── telegram/             # Telegram integration
│   │   ├── __init__.py
│   │   ├── listener.py       # Telethon client
│   │   ├── bot.py            # PTB bot commands
│   │   └── notifications.py  # Alert sender
│   ├── parser/               # Signal parsing engine
│   │   ├── __init__.py
│   │   ├── preprocessor.py   # Message cleaning
│   │   ├── patterns.py       # Keyword patterns
│   │   ├── extractor.py      # Price/symbol extraction
│   │   ├── validator.py      # Signal validation
│   │   └── schemas.py        # Pydantic models
│   ├── risk/                 # Risk management
│   │   ├── __init__.py
│   │   ├── position_sizer.py # Lot calculation
│   │   └── limits.py         # Exposure/loss limits
│   ├── executors/            # Platform executors
│   │   ├── __init__.py
│   │   ├── mt5/
│   │   │   ├── __init__.py
│   │   │   ├── zeromq.py
│   │   │   └── mql_bridge.py
│   │   └── tradingview/
│   │       ├── __init__.py
│   │       └── webhook.py
│   ├── journal/              # Trading journal
│   │   ├── __init__.py
│   │   ├── database.py       # DB connection & models
│   │   ├── trade_logger.py   # Trade event logging
│   │   └── analytics.py      # Statistics calculation
│   ├── reports/              # Report generation
│   │   ├── __init__.py
│   │   ├── daily.py
│   │   ├── weekly.py
│   │   ├── charts.py
│   │   └── pdf_generator.py
│   ├── core/                 # Shared infrastructure
│   │   ├── __init__.py
│   │   ├── redis_client.py
│   │   ├── state_manager.py
│   │   └── exceptions.py
│   └── main.py               # Application entry
├── mql5/                     # MQL5 Expert Advisors
│   └── SignalExecutorEA/
├── pinescript/               # TradingView Pine Scripts
│   └── SignalConnector.pine
├── config/                   # Runtime configs
│   ├── config.yaml
│   └── keywords/             # Per-provider keyword configs
│       ├── default.json
│       └── example_advanced.json
├── migrations/               # Alembic DB migrations
├── reports/                  # Generated report output
├── tests/
│   ├── unit/
│   ├── integration/
│   └── fixtures/
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
├── requirements.txt
├── pyproject.toml
└── .env.example
```

### 1.2 Week 1 Tasks

| Day | Task | Key Decisions |
|-----|------|---------------|
| 1-2 | **Project scaffolding** | Poetry for deps, Pydantic v2 for config, Python 3.11 |
| 2-3 | **Configuration system** | YAML config + env var overrides; Pydantic validation |
| 3-4 | **Telegram listener core** | Telethon async client; session persistence; multi-channel |
| 4-5 | **Message preprocessor** | Strip markdown; normalize unicode; expand abbreviations |

### 1.3 Week 2 Tasks

| Day | Task | Key Decisions |
|-----|------|---------------|
| 6-7 | **Keyword pattern system** | JSON-configurable; support `[X]` placeholders; multi-provider |
| 7-8 | **Signal extractor** | Regex-based price extraction; symbol matching; order type detection |
| 8-9 | **Signal validator** | Required field checks; price sanity; symbol whitelist; dedup |
| 9-10 | **Integration testing** | Unit tests for parser; sample signal fixtures; CI pipeline |

### Phase 1 Success Criteria
- Parse 90%+ of sample signals correctly
- Handle 5+ different signal formats
- Support edited message updates
- Configurable per-channel keyword dictionaries

---

## Phase 2: MT5 Integration (Week 3-4)

### 2.1 Week 3: ZeroMQ Connection

| Task | Description |
|------|-------------|
| ZeroMQ protocol | Implement REQ/REP socket to MQL5 EA |
| Connection manager | Auto-connect, heartbeat, reconnection |
| Order commands | Place, modify, close, partial close |
| Price feed | Real-time bid/ask for market orders |
| Error handling | Timeout, reject, slippage handling |

### 2.2 Week 4: Order Execution & MQL5 EA

| Task | Description |
|------|-------------|
| Order executor | Market/Limit/Stop orders; multi-TP splits |
| Position tracker | Monitor open positions; P&L tracking |
| MQL5 EA (fallback) | File-based signal reader; order execution |
| Trade confirmation | Verify execution; update journal |
| Risk integration | Position sizing before execution |

### Phase 2 Success Criteria
- Successfully place orders on MT5 demo account
- Handle all 6 order types
- Multi-TP position splitting
- Automatic retry on failure

---

## Phase 3: TradingView Integration (Week 5)

| Day | Task |
|-----|------|
| 1-2 | FastAPI webhook endpoint with secret verification |
| 2-3 | TradingView alert payload parser |
| 3-4 | Pine Script alert template (connector) |
| 4-5 | Integration with execution queue; end-to-end test |

---

## Phase 4: Trading Journal & Database (Week 6)

### 4.1 Database Setup

| Task | Description |
|------|-------------|
| PostgreSQL setup | Docker compose; create database |
| Alembic migrations | Version-controlled schema |
| SQLAlchemy models | All tables from architecture |
| Connection pooling | Async SQLAlchemy with proper pooling |

### 4.2 Journal Implementation

| Task | Description |
|------|-------------|
| Signal logger | Log every parsed signal with metadata |
| Trade lifecycle tracker | ENTRY → MODIFICATIONS → EXIT events |
| P&L calculator | Realized/unrealized P&L in currency and pips |
| Daily aggregator | Automated daily summary computation |
| Provider analytics | Win rate, R:R, profit factor per provider |

### Phase 4 Success Criteria
- Every signal stored with full metadata
- Trade events tracked (TP hit, SL hit, partial close, breakeven)
- Daily summaries auto-computed
- Queryable analytics API

---

## Phase 5: Reporting Engine (Week 7)

### 5.1 Report Components

| Component | Technology | Description |
|-----------|-----------|-------------|
| Data queries | SQL + Pandas | Aggregate trade statistics |
| Equity curve | matplotlib | Account balance over time chart |
| Win/loss chart | matplotlib | Daily win/loss bar chart |
| Symbol breakdown | matplotlib | Pie chart by symbol |
| R-multiple distribution | matplotlib | Histogram of R values |
| PDF assembly | reportlab | Multi-page PDF report |
| Telegram delivery | PTB | Formatted message + PDF file |

### 5.2 Daily Report Schedule
```
Cron: 0 5 * * * UTC  (Every day at 00:05 UTC)
```

**Sections**:
1. Executive Summary (trades, win rate, P&L)
2. Trade List (all trades of the day)
3. Charts (equity curve, symbol distribution)
4. Provider Performance
5. Risk Metrics (drawdown, consecutive losses)

### 5.3 Weekly Report Schedule
```
Cron: 10 0 * * 1 UTC  (Every Monday at 00:10 UTC)
```

**Sections**:
1. Week Overview
2. Day-by-Day Breakdown
3. Cumulative Performance
4. Provider Rankings
5. Detailed Charts
6. Insights & Recommendations

### Phase 5 Success Criteria
- Daily report auto-generated and delivered via Telegram
- Weekly PDF report with charts
- Reports archived and queryable

---

## Phase 6: Bot Interface & Polish (Week 8)

### 6.1 Telegram Bot Commands

| Command | Description | Access |
|---------|-------------|--------|
| `/start` | Welcome + quick setup guide | All users |
| `/connect` | Connect MT5 account | Authorized |
| `/channels` | List/manage monitored channels | Authorized |
| `/risk` | View/set risk parameters | Authorized |
| `/status` | System health + open positions | Authorized |
| `/journal` | View today's trades | Authorized |
| `/report` | Request manual report | Authorized |
| `/pause` | Pause all copying | Authorized |
| `/resume` | Resume copying | Authorized |
| `/providers` | View provider performance | Authorized |
| `/help` | Command reference | All users |

### 6.2 Admin Features
- Real-time system health dashboard
- Provider enable/disable
- Risk parameter overrides
- Manual signal injection (for testing)
- Log viewing

---

## Phase 7: Testing & Production (Week 9-10)

### 7.1 Testing Checklist

| Category | Tests |
|----------|-------|
| **Parser** | 50+ sample signals across 5 providers; edge cases; malformed signals |
| **MT5** | All order types; partial close; SL/TP modification; reconnection |
| **TradingView** | Webhook delivery; Pine Script alert; error handling |
| **Journal** | Trade lifecycle; P&L accuracy; report correctness |
| **Risk** | Position sizing accuracy; circuit breaker; exposure limits |
| **Integration** | End-to-end signal → trade → journal → report |

### 7.2 Demo Trading Requirements
- Minimum 2 weeks on demo account
- 50+ signals processed
- All report types generated
- No critical bugs

### 7.3 Production Deployment
- Docker Compose on VPS/cloud
- SSL for webhook endpoints
- PostgreSQL backups
- Redis persistence
- Monitoring (Prometheus + Grafana)
- Log rotation

---

## Key Milestones

| Milestone | Target Date | Deliverable |
|-----------|-------------|-------------|
| M1: Parser Complete | End Week 2 | Parses signals from 5+ providers |
| M2: MT5 Live | End Week 4 | Demo account executing trades |
| M3: Multi-Platform | End Week 5 | MT5 + TradingView both active |
| M4: Journal Live | End Week 6 | All trades logged, analytics working |
| M5: Reports Auto | End Week 7 | Daily/weekly reports auto-delivered |
| M6: Bot Complete | End Week 8 | All commands functional |
| M7: Production Ready | End Week 10 | Demo tested, deployed, stable |
